const express = require("express");
const axios = require("axios");

const app = express();
app.use(express.json());

// 1. Auth MiddleWare (NoteFlow Secret)
const authMiddleware = (req, res, next) => {
    const clientSecret = req.headers["x-noteflow-secret"];
    // WeChat Cloud Hosting uses environment variables for config
    const serverSecret = process.env.NOTEFLOW_SECRET;

    if (!clientSecret || clientSecret !== serverSecret) {
        return res.status(401).json({ error: "Unauthorized" });
    }
    next();
};

// 2. Draft Add Handler
app.post("/wechat/draft/add", authMiddleware, async (req, res) => {
    try {
        const accessToken = await getAccessToken();
        const wxUrl = `https://api.weixin.qq.com/cgi-bin/draft/add?access_token=${accessToken}`;

        const response = await axios.post(wxUrl, req.body);

        // Handle CORS (allow Obsidian)
        res.set("Access-Control-Allow-Origin", "*");
        res.json(response.data);
    } catch (err) {
        console.error("Draft add error:", err.message);
        res.status(500).json({ error: err.message });
    }
});

// 3. Health Check
app.get("/", (req, res) => {
    res.send("NoteFlow WeChat Cloud Hosting Proxy is running.");
});

// Helper: Get WeChat Access Token
let tokenCache = {
    token: "",
    expires: 0
};

async function getAccessToken() {
    const now = Date.now();
    if (tokenCache.token && tokenCache.expires > now) {
        return tokenCache.token;
    }

    const appId = process.env.WECHAT_APP_ID;
    const appSecret = process.env.WECHAT_APP_SECRET;

    if (!appId || !appSecret) {
        throw new Error("Missing WECHAT_APP_ID or WECHAT_APP_SECRET environment variables.");
    }

    const url = `https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=${appId}&secret=${appSecret}`;
    const response = await axios.get(url);
    const data = response.data;

    if (data.access_token) {
        tokenCache.token = data.access_token;
        tokenCache.expires = now + (data.expires_in - 200) * 1000; // Cache with buffer
        return data.access_token;
    }
    throw new Error(data.errmsg || "Failed to get access token");
}

const port = process.env.PORT || 80;
app.listen(port, () => {
    console.log(`Proxy listening on port ${port}`);
});
