# NoteFlow WeChat Cloud Hosting Proxy (Express.js)

This is a specialized proxy server designed for **WeChat Cloud Hosting (微信云托管)**. It provides a fixed outbound IP address, making it compatible with WeChat Official Account API's IP whitelisting requirements.

## Deployment Instructions

1.  **Preparation**: 
    *   Find the `infrastructure/wechat-cloud-hosting` folder in your NoteFlow project.
    *   Make sure you have `index.js`, `package.json`, and `Dockerfile` in this folder.

2.  **Open WeChat Cloud Hosting Console**:
    *   Navigate to **Settings & Development -> WeChat Cloud Hosting** in your WeChat MP dashboard.

3.  **Upload Code**:
    *   You can compress the contents of this folder into a `.zip` file and upload it directly in the **Service Deployment** tab.
    *   Alternatively, push this folder to a GitHub repository and link it.

4.  **Set Environment Variables**:
    *   In the Cloud Hosting console, go to **Environment Settings -> Variable Settings**.
    *   Add the following:
    *   `WECHAT_APP_ID`: Your WeChat AppID.
    *   `WECHAT_APP_SECRET`: Your WeChat AppSecret.
    *   `NOTEFLOW_SECRET`: Your custom API Key (must match the one in NoteFlow plugin settings).
    *   `PORT`: `80` (default for Cloud Hosting).

5.  **Enable Fixed IP**:
    *   Go to **Environment Settings -> Network Settings**.
    *   Enable **Fixed Outbound IP (固定公网出口 IP)**.
    *   Copy the resulting IP address.

6.  **Whitelist IP**:
    *   Go to WeChat MP **Basic Settings -> IP Whitelist**.
    *   Add the IP address from the previous step.

7.  **Update NoteFlow Settings**:
    *   Use your Cloud Hosting service's URL in the NoteFlow plugin settings.
